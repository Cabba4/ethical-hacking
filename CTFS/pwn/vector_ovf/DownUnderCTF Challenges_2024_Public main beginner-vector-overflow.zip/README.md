vector overflow
======================

- **Category**: pwn
- **Difficulty**: beginner
- **Author**: joseph
- **Tags**: 

Please overflow into the vector and control it!

---

### Handout files

- [./publish/vector_overflow](./publish/vector_overflow)
- [./publish/vector_overflow.cpp](./publish/vector_overflow.cpp)
